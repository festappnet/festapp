<?php
/** @copyright (C) 2026 Festapp. @license GNU GPL version 2 or later; see LICENSE.txt */
namespace Festapp\Module\VstupenkyOnline\Site\Dispatcher;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Festapp\Module\VstupenkyOnline\Site\Helper\EmbedHelper;

defined('_JEXEC') or die;

final class Dispatcher extends AbstractModuleDispatcher
{
    protected function getLayoutData()
    {
        $data = parent::getLayoutData();
        // Never load remote assets in administrator previews.
        $data['embed'] = '';
        if ($this->getApplication()->isClient('site')) {
            $settings = EmbedHelper::settings($data['params']->toArray());
            if ($settings !== null) {
                $assets = $this->getApplication()->getDocument()->getWebAssetManager();
                $handle = 'mod_vstupenky_online.embed';
                if (!$assets->assetExists('script', $handle)) {
                    $assets->registerScript($handle, 'https://vstupenky.online/embed.js', ['version' => false], ['defer' => true]);
                }
                $asset = $assets->getAsset('script', $handle);
                $config = EmbedHelper::consent($data['params']->toArray());
                if ($config !== null && !$asset->getOption('festappConsentConflict', false)) {
                    $encoded = json_encode($config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
                    $previous = $asset->getOption('festappConsentConfig');
                    if ($previous !== null && $previous !== $encoded) {
                        // Multiple incompatible imports cannot authorize a transfer.
                        $asset->setOption('festappConsentConflict', true);
                        $asset->setAttribute('data-festapp-consent', '');
                        $asset->setAttribute('data-cookieconsent', null);
                    } else {
                        $asset->setOption('festappConsentConfig', $encoded);
                        $asset->setAttribute('data-festapp-consent', $encoded);
                        if ($config['providerConfig']['provider'] === 'cookiebot') {
                            $asset->setAttribute('data-cookieconsent', 'ignore');
                        }
                    }
                }
                $assets->useScript($handle);
            }
            $data['embed'] = EmbedHelper::render($data['params']->toArray());
        }
        return $data;
    }
}
