<?php
/** @copyright (C) 2026 Festapp. @license GNU GPL version 2 or later; see LICENSE.txt */
namespace Festapp\Module\VstupenkyOnline\Site\Helper;

use Joomla\CMS\Language\Text;

defined('_JEXEC') or die;
require_once __DIR__ . '/consent-export.php';

final class EmbedHelper
{
    public static function validateUrl($input): bool
    {
        $prefix = 'https://vstupenky.online/form/';
        if (!is_string($input) || strlen($input) > 2048 || !str_starts_with($input, $prefix)) {
            return false;
        }
        $slug = substr($input, strlen($prefix));
        $decoded = rawurldecode($slug);
        return preg_match('/\A[\p{L}\p{N}_-]+\z/uD', $decoded) === 1 && rawurlencode($decoded) === $slug;
    }

    public static function settings(array $params): ?array
    {
        if (!self::validateUrl($params['url'] ?? null)) {
            return null;
        }
        $height = is_scalar($params['height'] ?? null) ? filter_var($params['height'], FILTER_VALIDATE_INT) : false;
        $height = $height !== false && $height >= 240 && $height <= 4000 ? $height : 800;
        $auto = ($params['mode'] ?? 'auto') !== 'fixed';
        $title = is_string($params['iframe_title'] ?? null) ? trim($params['iframe_title']) : '';
        return [
            'url' => $params['url'], 'height' => $height, 'auto' => $auto,
            'measurement' => ($params['measurement'] ?? 'unit') === 'host' ? 'host' : 'unit',
            'title' => $title !== '' ? $title : Text::_('MOD_VSTUPENKY_ONLINE_DEFAULT_TITLE'),
        ];
    }

    public static function consent(array $params): ?array
    {
        if (!in_array($params['consent_enabled'] ?? null, [1,'1',true], true)) { return null; }
        return \Festapp\CmsConsent\parse_export($params['consent_export'] ?? '', ['https://vstupenky.online'], \Festapp\CmsConsent\origin_from_url(\Joomla\CMS\Uri\Uri::root()));
    }

    public static function render(array $params): string
    {
        $s = self::settings($params);
        if ($s === null) {
            return '<p class="mod_vstupenky_online-error">' . self::escape(Text::_('MOD_VSTUPENKY_ONLINE_INVALID_URL')) . '</p>';
        }
        $config = self::consent($params);
        $rel = $config ? 'data-festapp-consent-link' : 'rel="noopener noreferrer"';
        if (($params['display'] ?? 'embed') === 'link') {
            return '<a href="' . self::escape($s['url']) . '" target="_blank" ' . $rel . '>' . self::escape($s['title']) . '</a>';
        }
        return sprintf(
            '<div class="mod_vstupenky_online" data-festapp-embed-host><iframe%s src="%s" title="%s" height="%d" style="display:block;width:100%%;max-width:100%%;border:0;color-scheme:light dark" loading="lazy"></iframe><p><a href="%s" target="_blank" %s>%s</a></p></div>',
            ' data-festapp-embed' . (!$s['auto'] ? ' data-festapp-height="fixed"' : '')
                . ($s['measurement'] === 'host' ? ' data-festapp-datalayer' : ''),
            self::escape($s['url'] . '?embed=1'), self::escape($s['title']), $s['height'],
            self::escape($s['url']), $rel, self::escape(Text::_('MOD_VSTUPENKY_ONLINE_FALLBACK'))
        );
    }

    private static function escape(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
