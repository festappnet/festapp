<?php
namespace Festapp\Module\VstupenkyOnline\Site\Field;
use Joomla\CMS\Form\FormField;
use Joomla\CMS\Language\Text;
use Festapp\Module\VstupenkyOnline\Site\Helper\EmbedHelper;
defined('_JEXEC') or die;
final class ConsentstatusField extends FormField
{
    protected $type = 'Consentstatus';
    protected function getInput()
    {
        $config = EmbedHelper::consent(['consent_enabled'=>$this->form->getValue('consent_enabled','params'), 'consent_export'=>$this->form->getValue('consent_export','params')]);
        $key = $config ? 'MOD_VSTUPENKY_ONLINE_CONSENT_ACCEPTED' : 'MOD_VSTUPENKY_ONLINE_CONSENT_OFF';
        return '<p>' . htmlspecialchars(Text::_($key), ENT_QUOTES, 'UTF-8') . '</p><p>' . htmlspecialchars(Text::_('MOD_VSTUPENKY_ONLINE_CONSENT_COOP'), ENT_QUOTES, 'UTF-8') . '</p>';
    }
}
