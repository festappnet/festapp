<?php
/** @copyright (C) 2026 Festapp. @license GNU GPL version 2 or later; see LICENSE.txt */
namespace Festapp\Module\FestappTickets\Site\Rule;

use Joomla\CMS\Form\Form;
use Joomla\CMS\Form\FormRule;
use Joomla\Registry\Registry;
use Festapp\Module\FestappTickets\Site\Helper\EmbedHelper;

defined('_JEXEC') or die;

final class PublicformRule extends FormRule
{
    public function test(\SimpleXMLElement $element, $value, $group = null, ?Registry $input = null, ?Form $form = null)
    {
        return EmbedHelper::validateUrl($value);
    }
}
