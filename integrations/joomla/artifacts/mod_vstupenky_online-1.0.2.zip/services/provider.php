<?php
/** @copyright (C) 2026 Festapp. @license GNU GPL version 2 or later; see LICENSE.txt */
defined('_JEXEC') or die;

use Joomla\CMS\Extension\Service\Provider\Module;
use Joomla\CMS\Extension\Service\Provider\ModuleDispatcherFactory;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class implements ServiceProviderInterface {
    public function register(Container $container)
    {
        $container->registerServiceProvider(new ModuleDispatcherFactory('\\Festapp\\Module\\VstupenkyOnline'));
        $container->registerServiceProvider(new Module());
    }
};
