<?php
/** @copyright (C) 2026 Festapp. @license GNU GPL version 2 or later; see LICENSE.txt */
namespace Festapp\Module\VstupenkyOnline\Site\Dispatcher;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Festapp\Module\VstupenkyOnline\Site\Helper\EmbedHelper;

defined('_JEXEC') or die;

final class Dispatcher extends AbstractModuleDispatcher
{
    protected function getLayoutData()
    {
        $data = parent::getLayoutData();
        // Never load remote assets in administrator previews.
        $data['embed'] = '';
        if ($this->getApplication()->isClient('site')) {
            $settings = EmbedHelper::settings($data['params']->toArray());
            if ($settings !== null) {
                $assets = $this->getApplication()->getDocument()->getWebAssetManager();
                $handle = 'mod_vstupenky_online.embed';
                if (!$assets->assetExists('script', $handle)) {
                    $assets->registerScript($handle, 'https://vstupenky.online/embed.js', ['version' => false], ['defer' => true]);
                }
                $assets->useScript($handle);
            }
            $data['embed'] = EmbedHelper::render($data['params']->toArray());
        }
        return $data;
    }
}
