<?php
/** @copyright (C) 2026 Festapp. @license GNU GPL version 2 or later; see LICENSE.txt */
namespace Festapp\Module\FestappTickets\Site\Dispatcher;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Festapp\Module\FestappTickets\Site\Helper\EmbedHelper;

defined('_JEXEC') or die;

final class Dispatcher extends AbstractModuleDispatcher
{
    protected function getLayoutData()
    {
        $data = parent::getLayoutData();
        // Never load remote assets in administrator previews.
        $data['embed'] = '';
        if ($this->getApplication()->isClient('site')) {
            $settings = EmbedHelper::settings($data['params']->toArray());
            if ($settings !== null) {
                $assets = $this->getApplication()->getDocument()->getWebAssetManager();
                $handle = 'mod_festapp_tickets.embed';
                if (!$assets->assetExists('script', $handle)) {
                    $assets->registerScript($handle, 'https://tickets.festapp.net/embed.js', ['version' => false], ['defer' => true]);
                }
                $assets->useScript($handle);
            }
            $data['embed'] = EmbedHelper::render($data['params']->toArray());
        }
        return $data;
    }
}
