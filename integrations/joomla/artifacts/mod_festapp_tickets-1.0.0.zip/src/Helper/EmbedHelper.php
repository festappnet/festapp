<?php
/** @copyright (C) 2026 Festapp. @license GNU GPL version 2 or later; see LICENSE.txt */
namespace Festapp\Module\FestappTickets\Site\Helper;

use Joomla\CMS\Language\Text;

defined('_JEXEC') or die;

final class EmbedHelper
{
    public static function validateUrl($input): bool
    {
        $prefix = 'https://tickets.festapp.net/form/';
        if (!is_string($input) || strlen($input) > 2048 || !str_starts_with($input, $prefix)) {
            return false;
        }
        $slug = substr($input, strlen($prefix));
        $decoded = rawurldecode($slug);
        return preg_match('/\A[\p{L}\p{N}_-]+\z/uD', $decoded) === 1 && rawurlencode($decoded) === $slug;
    }

    public static function settings(array $params): ?array
    {
        if (!self::validateUrl($params['url'] ?? null)) {
            return null;
        }
        $height = is_scalar($params['height'] ?? null) ? filter_var($params['height'], FILTER_VALIDATE_INT) : false;
        $height = $height !== false && $height >= 240 && $height <= 4000 ? $height : 800;
        $auto = ($params['mode'] ?? 'auto') !== 'fixed';
        $title = is_string($params['iframe_title'] ?? null) ? trim($params['iframe_title']) : '';
        return [
            'url' => $params['url'], 'height' => $height, 'auto' => $auto,
            'title' => $title !== '' ? $title : Text::_('MOD_FESTAPP_TICKETS_DEFAULT_TITLE'),
        ];
    }

    public static function render(array $params): string
    {
        $s = self::settings($params);
        if ($s === null) {
            return '<p class="mod_festapp_tickets-error">' . self::escape(Text::_('MOD_FESTAPP_TICKETS_INVALID_URL')) . '</p>';
        }
        return sprintf(
            '<div class="mod_festapp_tickets" data-festapp-embed-host><iframe%s src="%s" title="%s" height="%d" style="display:block;width:100%%;max-width:100%%;border:0" loading="lazy"></iframe><p><a href="%s" target="_blank" rel="noopener noreferrer">%s</a></p></div>',
            ' data-festapp-embed' . (!$s['auto'] ? ' data-festapp-height="fixed"' : ''),
            self::escape($s['url'] . '?embed=1'), self::escape($s['title']), $s['height'],
            self::escape($s['url']), self::escape(Text::_('MOD_FESTAPP_TICKETS_FALLBACK'))
        );
    }

    private static function escape(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
